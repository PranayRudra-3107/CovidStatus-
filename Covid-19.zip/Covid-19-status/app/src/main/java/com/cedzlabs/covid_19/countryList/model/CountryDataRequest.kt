package com.cedzlabs.covid_19.countryList.model

class CountryDataRequest {
}
