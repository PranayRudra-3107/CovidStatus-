package com.cedzlabs.covid_19.countryList.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import com.cedzlabs.covid_19.countryList.repository.CountryListRepository
import com.cedzlabs.covid_19.countryList.model.CountryDataResponse

class CountryListViewModel: ViewModel() {
    private var countryListRepository: CountryListRepository =
        CountryListRepository()
    lateinit var responseLiveData: LiveData<CountryDataResponse>

    fun fetchCountryDataList() {
        responseLiveData = countryListRepository.fetchCountryListData()
    }
}
