package com.cedzlabs.covid_19

class AppConstants {
    companion object {
        const val host: String = "covid-193.p.rapidapi.com"
        const val key: String  = "vSNplr4W3vmshXpckBSe25fr4fmGp1Q0cb2jsnARGQukbqee5g"
        const val flagUrl: String = "https://www.countryflags.io/%s/flat/64.png"
        const val newsApiKey: String ="c698a903ba9b404f865835fbb37d8116"
        const val whoUrl: String = "https://www.who.int/"
    }
}
