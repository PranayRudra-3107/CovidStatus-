# COVID-19 MONITOR

**Hey, I've been working and developing the mobile application which helps you to montior Real time Status of Covid-19 stats.**

So i've basically divided my application to 5 major parts..
1. Symptoms
2. Prevention
3. Reports
4. Countries Stats
5. Covid-19 News

* Symptoms and Prevention gives you little bit of information about Covid-19.
* Reports shows you the total counts for Covid-19 patients with the pie-chart for India and the rest of the World.
* Countries Screen shows you the list of all the Covid affected countries with the recent stats.
* Covid News Screen gives you the recent news about Coivd-19
* Made it with such UI/UX, that every user will love the the flow.

*Covid-19 Android Application which gives the real time update and helps you to know more about the disease.*

**Attached Evidence...**
# Welcome, Symptoms, Prevention
<img src="https://user-images.githubusercontent.com/26492582/78907291-2442cb00-7a9e-11ea-9f3d-24b9cb7336ac.png" width="250" height="500"/>   <img src="https://user-images.githubusercontent.com/26492582/78907304-27d65200-7a9e-11ea-83f3-e78f157e626e.png" width="250" height="500"/>    <img src="https://user-images.githubusercontent.com/26492582/78907310-286ee880-7a9e-11ea-9a83-51948e9f9926.png" width="250" height="500"/>

# Stats (Reports, Loading Screen, Countries)
<img src="https://user-images.githubusercontent.com/26492582/78907313-29077f00-7a9e-11ea-92af-e71ff7831df6.png" width="250" height="500"/>    <img src="https://user-images.githubusercontent.com/26492582/78907316-29a01580-7a9e-11ea-8dc1-76665cae2794.png" width="250" height="500"/>    <img src="https://user-images.githubusercontent.com/26492582/78907320-2ad14280-7a9e-11ea-90c5-f63f3c2a6957.png" width="250" height="500"/> 
 
# News (Covid-19 News, Loading Screen)
<img src="https://user-images.githubusercontent.com/26492582/78907324-2b69d900-7a9e-11ea-9c11-12a50b2764a3.png" width="250" height="500"/>   <img src="https://user-images.githubusercontent.com/26492582/78907322-2b69d900-7a9e-11ea-86c5-22e5e899f65b.png" width="250" height="500"/>

